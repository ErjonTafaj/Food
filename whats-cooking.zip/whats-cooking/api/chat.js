export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { messages, pantryCtx, weekCtx } = req.body;

  const systemPrompt = `You are a personal cooking assistant built into a meal planning app for Erjon, a young Albanian man living alone in Charlotte, NC.

ABOUT ERJON:
- Cooks for himself (1 person), beginner-intermediate cook
- Has a Ninja Dual Zone air fryer with Smart Finish (can cook 2 things at once!)
- Likes: chicken, beef, pork, shrimp, mushrooms, zucchini, potatoes, pasta, rice
- Does NOT like sweet food in main meals
- Likes some spice occasionally
- Batch cooks Mon/Wed for office lunches Tue/Thu
- Weekend = nicer meals, weekday = quick and easy
- Breakfast: 2 boiled eggs + banana every day
- Evening snack: yogurt + fruits + honey

PANTRY (in stock right now): ${pantryCtx || 'unknown'}

THIS WEEK'S PLAN: ${weekCtx || 'not set yet'}

Be friendly, conversational, practical, and specific. No em dashes. Keep it short and direct.`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1000,
        system: systemPrompt,
        messages,
      }),
    });

    const data = await response.json();
    const reply = data.content?.[0]?.text || 'Something went wrong, try again!';
    res.status(200).json({ reply });
  } catch (error) {
    console.error('API error:', error);
    res.status(500).json({ reply: 'Something went wrong. Try again!' });
  }
}
